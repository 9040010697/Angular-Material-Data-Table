import {Component, ViewChild} from '@angular/core';
import { CoronaClientServiceService } from './services/corona-client-service.service';
import { MatSort, Sort } from '@angular/material/sort';
import {PageEvent} from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

const columns: string[] = ['country', 'cases', 'deaths', 'todayCases',
'todayDeaths', 'recovered', 'active', 'critical', 'flag'];

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 @ViewChild(MatSort, {static: true}) sort: MatSort;
  public pageEvent: PageEvent;
  public displayedColumns = columns;
  public dataSource: MatTableDataSource<any>;
  public data: Array<any>;
  public pageSizeOptions: number[];
  public length = 0;
  public pageSize = 25;
  public pageIndex = 0;
  public selectedRowIndex: number;
  constructor(public service: CoronaClientServiceService) {

    this.service.getCurrentStatus()
    .subscribe((success) => {
      this.data = success as Array<any>;
      this.length = this.data.length;
      this.dataSource = new MatTableDataSource(this.data.slice(0, 25));
      this.pageSizeOptions = [5, 10, 25, 50, 100, this.length];
    }, (err) => {
      console.log(err);
    });
  }

  applyFilter(event: Event) {
    this.dataSource = new MatTableDataSource(this.data.slice(0, this.length));
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if ( this.dataSource.filter.length === 0) {
      this.dataSource = new MatTableDataSource(this.data.slice(0, this.pageSize));
    }
  }


  compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }
  sortData(sort: Sort) {
    const data = this.dataSource.data.slice();
    if (!sort.active || sort.direction === '') {
      this.dataSource.data = data;
      return;
    }

    this.dataSource.data = data.sort((a: any, b: any) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'country': return this.compare(a.country, b.country, isAsc);
        case 'cases': return this.compare(a.cases, b.cases, isAsc);
        case 'deaths': return this.compare(a.deaths, b.deaths, isAsc);
        case 'todayCases': return this.compare(a.todayCases, b.todayCases, isAsc);
        case 'todayDeaths': return this.compare(a.todayDeaths, b.todayDeaths, isAsc);
        case 'recovered': return this.compare(a.recovered, b.recovered, isAsc);
        case 'active': return this.compare(a.active, b.active, isAsc);
        case 'critical': return this.compare(a.critical, b.critical, isAsc);
        default: return 0;
      }
    });
  }
  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  }
  public getServerData(event: PageEvent) {
    const d = this.data as Array<any>;
    this.dataSource.data =  d.slice((event.pageSize * event.pageIndex), event.pageSize * (event.pageIndex + 1));
    return event;
  }
}
